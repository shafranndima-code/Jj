# PrettyHUD – Petals & Circles Assets

![Preview](preview.png)

Ресурспак (assets) для мода/плагина **PrettyHUD**: 16 предметов с плоскими моделями — декоративные круги и лепестки для HUD-эффектов.

Resource pack assets for **PrettyHUD**: 16 flat item models — decorative circles and petals for HUD effects.

## Содержимое / Contents

| Тип / Type | Варианты / Variants | Текстура / Texture |
|---|---|---|
| `circle_diamond_*` | cyan, gold, pink, purple | 256×256 |
| `circle_rune_*` | cyan, gold, pink, purple | 256×256 |
| `circle_triangle_*` | cyan, gold, pink, purple | 256×256 |
| `petal_*` | cyan, pink, sakura, white | 32×32 |

Круги — горизонтальные плоскости (`y = 7.9…8.1`), лепестки — вертикальные (`z = 7.9…8.1`), двусторонние.

## Структура / Structure

```
pack.mcmeta
assets/prettyhud/
├── items/            # item definitions (1.21.4+)
├── models/item/      # flat models
└── textures/item/    # PNG textures
```

## Использование / Usage

1. Скопируйте папку репозитория (или ZIP) в `resourcepacks/`.
2. Включите пак в настройках ресурспаков.
3. Предметы доступны через `prettyhud:item_model`, например:

```
/give @s minecraft:paper[item_model="prettyhud:circle_rune_gold"]
```

> Формат `items/*.json` требует Minecraft **1.21.4+**. При необходимости поправьте `pack_format` в `pack.mcmeta` под вашу версию.

## Лицензия / License

[MIT](LICENSE)
