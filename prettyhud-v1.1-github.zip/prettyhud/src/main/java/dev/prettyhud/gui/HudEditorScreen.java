package dev.prettyhud.gui;

import dev.prettyhud.config.HudConfig;
import dev.prettyhud.config.Theme;
import dev.prettyhud.hud.HudRenderer;
import dev.prettyhud.hud.HudWidget;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

/** Редактор расположения: тяни плашки мышью. ПКМ по плашке сбрасывает её к правому/стандартному положению. */
public class HudEditorScreen extends Screen {
    private final Screen parent;
    private HudWidget dragged = null;
    private int offX, offY;

    public HudEditorScreen(Screen parent) {
        super(Component.literal("HUD"));
        this.parent = parent;
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float delta) {
        Theme t = HudConfig.get().theme();
        g.fill(0, 0, width, height, Theme.argb(0x000000, 0.35f));
        for (HudWidget w : HudRenderer.WIDGETS) {
            HudRenderer.drawWidget(g, minecraft, w, true);
            int[] b = HudRenderer.bounds(minecraft, w);
            int col = Theme.argb(t.primary(), w == dragged ? 1f : 0.55f);
            g.fill(b[0] - 2, b[1] - 2, b[0] + b[2] + 2, b[1] - 1, col);
            g.fill(b[0] - 2, b[1] + b[3] + 1, b[0] + b[2] + 2, b[1] + b[3] + 2, col);
            g.fill(b[0] - 2, b[1] - 2, b[0] - 1, b[1] + b[3] + 2, col);
            g.fill(b[0] + b[2] + 1, b[1] - 2, b[0] + b[2] + 2, b[1] + b[3] + 2, col);
            g.drawString(font, w.title, b[0], b[1] - 12, Theme.argb(0xFFFFFF, 0.8f), false);
        }
        String hint = "Перетаскивай плашки мышью  •  ПКМ — сбросить позицию  •  Esc — назад";
        g.drawString(font, hint, (width - font.width(hint)) / 2, height - 18, Theme.argb(0xFFFFFF, 0.8f), false);
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        int mx = (int) event.x(), my = (int) event.y();
        for (int i = HudRenderer.WIDGETS.size() - 1; i >= 0; i--) {
            HudWidget w = HudRenderer.WIDGETS.get(i);
            int[] b = HudRenderer.bounds(minecraft, w);
            if (Ctl.in(mx, my, b[0], b[1], b[2], b[3])) {
                HudConfig.Widget s = w.settings(HudConfig.get());
                if (event.button() == 1) { // ПКМ — сброс
                    s.x = w == HudRenderer.WIDGETS.get(2) ? -1 : 8;
                    s.y = w == HudRenderer.WIDGETS.get(2) ? -1 : (w == HudRenderer.WIDGETS.get(1) ? 8 : 60);
                    return true;
                }
                dragged = w;
                offX = mx - b[0];
                offY = my - b[1];
                return true;
            }
        }
        return super.mouseClicked(event, doubleClick);
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent event, double dx, double dy) {
        if (dragged == null) return super.mouseDragged(event, dx, dy);
        HudConfig.Widget s = dragged.settings(HudConfig.get());
        int[] b = HudRenderer.bounds(minecraft, dragged);
        s.x = Math.max(0, Math.min(width - b[2], (int) event.x() - offX));
        s.y = Math.max(0, Math.min(height - b[3], (int) event.y() - offY));
        return true;
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent event) {
        dragged = null;
        HudConfig.save();
        return super.mouseReleased(event);
    }

    @Override
    public void onClose() {
        HudConfig.save();
        minecraft.setScreen(parent);
    }

    @Override
    public boolean isPauseScreen() { return false; }
}
