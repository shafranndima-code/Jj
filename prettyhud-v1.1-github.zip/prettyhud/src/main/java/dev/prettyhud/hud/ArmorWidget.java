package dev.prettyhud.hud;

import dev.prettyhud.config.HudConfig;
import dev.prettyhud.config.Theme;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;

/** Вертикальная колонка: иконка предмета брони + оставшаяся прочность и полоска. */
public class ArmorWidget extends HudWidget {
    private static final EquipmentSlot[] SLOTS = {
            EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET };
    private static final int ROW_H = 20;

    private final ItemStack[] stacks = new ItemStack[4];
    private final String[] labels = new String[4];
    private final float[] frac = new float[4];
    private int count;
    private int labelW;

    public ArmorWidget() { super("armor", "Броня"); }

    @Override public HudConfig.Widget settings(HudConfig c) { return c.armor; }

    @Override
    public boolean measure(Minecraft mc) {
        if (mc.player == null) return false;
        count = 0;
        labelW = 0;
        for (EquipmentSlot s : SLOTS) {
            ItemStack st = mc.player.getItemBySlot(s);
            if (st.isEmpty()) continue;
            stacks[count] = st;
            if (st.isDamageableItem()) {
                int left = st.getMaxDamage() - st.getDamageValue();
                labels[count] = Integer.toString(left);
                frac[count] = (float) left / st.getMaxDamage();
            } else {
                labels[count] = "";
                frac[count] = 1f;
            }
            labelW = Math.max(labelW, mc.font.width(labels[count]));
            count++;
        }
        if (count == 0) return false;
        boolean showNum = HudConfig.get().armorShowDurability;
        width = 5 + 16 + (showNum ? 4 + Math.max(labelW, 18) : 0) + 5;
        height = 4 + count * ROW_H;
        return true;
    }

    @Override
    public boolean measureForEditor(Minecraft mc) {
        count = 4;
        for (int i = 0; i < 4; i++) { stacks[i] = ItemStack.EMPTY; labels[i] = "000"; frac[i] = 0.8f - i * 0.15f; }
        width = 5 + 16 + 4 + 18 + 5;
        height = 4 + count * ROW_H;
        return true;
    }

    @Override
    public void render(GuiGraphics g, Minecraft mc) {
        HudConfig c = HudConfig.get();
        Theme t = c.theme();
        Draw.panel(g, 0, 0, width, height, t);
        int y = 3;
        for (int i = 0; i < count; i++) {
            if (!stacks[i].isEmpty()) g.renderItem(stacks[i], 5, y);
            else g.fill(5, y, 21, y + 16, Draw.a(0xFFFFFF, 0.08f));
            if (c.armorShowDurability) {
                int color = Theme.lerp(0xFF4057, t.primary(), Math.min(1f, frac[i] * 1.2f));
                g.drawString(mc.font, labels[i], 5 + 16 + 4, y + 1, Draw.a(color, 1f), false);
                int bw = width - (5 + 16 + 4) - 5;
                g.fill(5 + 16 + 4, y + 12, 5 + 16 + 4 + bw, y + 14, Draw.a(0xFFFFFF, 0.10f));
                g.fill(5 + 16 + 4, y + 12, 5 + 16 + 4 + Math.round(bw * frac[i]), y + 14, Draw.a(color, 1f));
            }
            y += ROW_H;
        }
    }
}
