package dev.prettyhud.hud;

import dev.prettyhud.config.HudConfig;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.Identifier;

import java.util.List;

public final class HudRenderer {
    public static final List<HudWidget> WIDGETS = List.of(new PotionWidget(), new StatsWidget(), new ArmorWidget());

    private HudRenderer() {}

    public static void register() {
        HudElementRegistry.attachElementAfter(
                VanillaHudElements.MISC_OVERLAYS,
                Identifier.fromNamespaceAndPath("prettyhud", "widgets"),
                HudRenderer::render);
    }

    private static void render(GuiGraphics g, DeltaTracker tick) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options.hideGui) return;
        for (HudWidget w : WIDGETS) drawWidget(g, mc, w, false);
    }

    /** Рисует один виджет. В редакторе показывает макет, если реальных данных нет. */
    public static void drawWidget(GuiGraphics g, Minecraft mc, HudWidget w, boolean editor) {
        HudConfig cfg = HudConfig.get();
        HudConfig.Widget s = w.settings(cfg);
        if (!s.enabled && !editor) return;
        boolean ok = editor ? w.measureForEditor(mc) : w.measure(mc);
        if (!ok) return;

        float k = cfg.scale;
        int x = w.screenX(s, mc.getWindow().getGuiScaledWidth());
        int y = w.screenY(s, mc.getWindow().getGuiScaledHeight());

        g.pose().pushMatrix();
        g.pose().translate(x, y);
        g.pose().scale(k, k);
        w.render(g, mc);
        g.pose().popMatrix();
    }

    /** Прямоугольник виджета на экране (для перетаскивания). */
    public static int[] bounds(Minecraft mc, HudWidget w) {
        HudConfig cfg = HudConfig.get();
        HudConfig.Widget s = w.settings(cfg);
        int x = w.screenX(s, mc.getWindow().getGuiScaledWidth());
        int y = w.screenY(s, mc.getWindow().getGuiScaledHeight());
        return new int[]{x, y, Math.round(w.width() * cfg.scale), Math.round(w.height() * cfg.scale)};
    }
}
