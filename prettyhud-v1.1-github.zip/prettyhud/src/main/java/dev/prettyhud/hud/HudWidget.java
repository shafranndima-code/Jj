package dev.prettyhud.hud;

import dev.prettyhud.config.HudConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

/** Базовый класс виджета HUD. Размер вычисляется один раз за кадр в measure(), затем рисуется в render(). */
public abstract class HudWidget {
    public final String id;
    public final String title;
    protected int width, height;

    protected HudWidget(String id, String title) {
        this.id = id;
        this.title = title;
    }

    public abstract HudConfig.Widget settings(HudConfig c);

    /** Вычислить width/height по текущему состоянию игры. Возвращает false, если рисовать нечего. */
    public abstract boolean measure(Minecraft mc);

    /** Нарисовать содержимое с левым верхним углом (0,0) — смещение и масштаб применяет вызывающий. */
    public abstract void render(GuiGraphics g, Minecraft mc);

    /** Пример содержимого для редактора HUD, когда реальных данных нет. */
    public boolean measureForEditor(Minecraft mc) {
        return measure(mc);
    }

    public int width() { return width; }
    public int height() { return height; }

    /** Реальные координаты на экране с учётом привязки (-1 = правый/нижний край). */
    public int screenX(HudConfig.Widget s, int guiWidth) {
        float k = HudConfig.get().scale;
        return s.x < 0 ? guiWidth - Math.round(width * k) - 8 : s.x;
    }

    public int screenY(HudConfig.Widget s, int guiHeight) {
        float k = HudConfig.get().scale;
        return s.y < 0 ? (guiHeight - Math.round(height * k)) / 2 : s.y;
    }
}
